Back-Door Out: A Text-Based Adventure Game
------------------------------------------------
To install:
Extract the zip file to the directory you want.
For simplicity, it is recommended to place the folder in your local disk (C:\ or E:\, etc.)

The zip file contains the executable file (.jar) and the source code in a source folder.
------------------------------------------------
To play:
Open "Command Prompt" by opening the Start menu and typing "cmd" in the search bar.

Navigate to your install location using the cd command
(Ex. cd C:\BackDoorOut)
Type "java -jar BackDoorOut.jar" in the command box.

Play the game!
------------------------------------------------
Controls:
Press Enter to start the game.
When prompted for a number, enter the number you want and press Enter.
When prompted for a word, enter the word you want and press Enter.
Press Enter to advance dialog.
------------------------------------------------